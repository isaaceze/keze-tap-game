(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_0833f5a9._.js",
  "static/chunks/src_app_ClientBody_tsx_a9fb1e66._.js"
],
    source: "dynamic"
});
